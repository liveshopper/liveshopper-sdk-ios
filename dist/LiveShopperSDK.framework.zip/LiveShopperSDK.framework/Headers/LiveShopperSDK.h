@import Foundation;

FOUNDATION_EXPORT double const LiveShopperSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char SLiveShopperSDKVersionString[];

