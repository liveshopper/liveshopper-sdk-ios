#import <Foundation/Foundation.h>

FOUNDATION_EXPORT double const LiveShopperSDKVersionNumber;
FOUNDATION_EXPORT const unsigned char SLiveShopperSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LiveShopeprSDK/PublicHeader.h
